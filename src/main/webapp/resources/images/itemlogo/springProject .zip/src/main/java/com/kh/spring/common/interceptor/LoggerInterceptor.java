package com.kh.spring.common.interceptor;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.log;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.lang.Nullable;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LoggerInterceptor implements HandlerInterceptor {
	
	// 전처리 Handle 호출전
	@Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) 
    		throws Exception {
        log.debug("====================================================");
        log.debug(request.getMethod() + " " + request.getRequestURI());
        log.debug("----------------------------------------------------");
        return true;
    }
	
	// 후처리 Handel 리턴 후
	@Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) 
    		throws Exception {
		log.debug("-----------------------------------------------------");
        log.debug("ModelAndView = " + modelAndView);      
    }
		
	// view단 응답처리 후
	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
			@Nullable Exception ex) throws Exception {
		log.debug("____________________________________________________");
		log.debug("end");
		log.debug("====================================================");
		log.debug(" ");
	}
	

}
