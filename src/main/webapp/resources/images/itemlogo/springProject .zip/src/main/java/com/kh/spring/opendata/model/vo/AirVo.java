package com.kh.spring.opendata.model.vo;


public class AirVo {

}
